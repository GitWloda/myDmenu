document.querySelector('#logo').addEventListener('click',function(){
    window.open('https://myanimelist.net/');
})
document.getElementById('github').onclick = function(){
    window.open("https://github.com/HritikVaishnav/Myanimelist-Redesigned")
};
document.getElementById('support').onclick = function(){
    window.open("https://hritikvaishnav.github.io/Project-Redesign/public/donation.html")
};