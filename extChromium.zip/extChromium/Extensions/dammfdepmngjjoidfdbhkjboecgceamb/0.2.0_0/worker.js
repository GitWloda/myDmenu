'use strict';

chrome.runtime.onMessage.addListener((request, sender) => {
  if (request.method === 'observe-state-changes') {
    chrome.scripting.executeScript({
      target: {
        tabId: sender.tab.id,
        frameIds: [sender.frameId]
      },
      world: 'MAIN',
      func: period => {
        const player = document.querySelector('.html5-video-player');
        if (player.ready) {
          return;
        }

        const parent = document.querySelector('.pprogg');
        let id;
        const act = () => {
          parent.style.setProperty('--progress', (player.getCurrentTime() / player.getDuration() * 100).toFixed(2) + '%');
          parent.style.setProperty('--loaded', (player.getVideoLoadedFraction() * 100).toFixed(2) + '%');
        };
        const onStateChange = e => {
          clearInterval(id);
          if (e === 1) {
            id = setInterval(act, period);
          }
          act();
        };

        player.ready = true;
        player.addEventListener('onStateChange', onStateChange);
        if (player.getPlayerState() === 1) {
          onStateChange(1);
        }
      },
      args: [request.period]
    });
  }
});

/* FAQs & Feedback */
{
  const {management, runtime: {onInstalled, setUninstallURL, getManifest}, storage, tabs} = chrome;
  if (navigator.webdriver !== true) {
    const page = getManifest().homepage_url;
    const {name, version} = getManifest();
    onInstalled.addListener(({reason, previousVersion}) => {
      management.getSelf(({installType}) => installType === 'normal' && storage.local.get({
        'faqs': true,
        'last-update': 0
      }, prefs => {
        if (reason === 'install' || (prefs.faqs && reason === 'update')) {
          const doUpdate = (Date.now() - prefs['last-update']) / 1000 / 60 / 60 / 24 > 45;
          if (doUpdate && previousVersion !== version) {
            tabs.query({active: true, currentWindow: true}, tbs => tabs.create({
              url: page + '&version=' + version + (previousVersion ? '&p=' + previousVersion : '') + '&type=' + reason,
              active: reason === 'install',
              ...(tbs && tbs.length && {index: tbs[0].index + 1})
            }));
            storage.local.set({'last-update': Date.now()});
          }
        }
      }));
    });
    setUninstallURL(page + '&rd=feedback&name=' + encodeURIComponent(name) + '&version=' + version);
  }
}
