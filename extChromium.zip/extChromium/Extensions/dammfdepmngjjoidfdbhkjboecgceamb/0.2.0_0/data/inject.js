'use strict';

const observe = () => {
  if (document.querySelector('.pprogg')) {
    return;
  }
  const p = document.querySelector('.html5-video-player');

  if (p) {
    chrome.storage.local.get({
      'height': 3,
      'top': true,
      'embed': true,
      'period': 2000,
      'padding': 12,
      'parent-color': 'rgba(255, 255, 255, 0.2)',
      'progress-color': '#fe0000',
      'loaded-color': 'rgba(255, 255, 255, 0.4)'
    }, prefs => {
      if (
        (prefs.embed !== false && window.top !== window) ||
        (prefs.top !== false && window.top === window)
      ) {
        const parent = document.createElement('div');
        parent.classList.add('pprogg');
        parent.style.setProperty('--height', prefs.height + 'px');
        parent.style.setProperty('--padding', prefs.padding + 'px');
        parent.style.setProperty('--parent-color', prefs['parent-color']);
        parent.style.setProperty('--progress-color', prefs['progress-color']);
        parent.style.setProperty('--loaded-color', prefs['loaded-color']);
        const el = document.createElement('div');
        el.dataset.type = 'loaded';
        parent.appendChild(el);
        const pl = document.createElement('div');
        pl.dataset.type = 'progress';
        parent.appendChild(pl);
        p.appendChild(parent);

        chrome.runtime.sendMessage({
          method: 'observe-state-changes',
          period: prefs.period
        });
      }
    });
  }
  else {
    console.warn('cannot find the player');
  }
};

// top frame
window.addEventListener('yt-navigate-finish', () => {
  observe();
});
// embedded YouTube
window.addEventListener('play', () => {
  observe();
}, true);
