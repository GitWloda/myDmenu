'use strict';
chrome.runtime.onInstalled.addListener(function (details) {
    if (details.reason == "install") {
        chrome.storage.local.set({
            style: chrome.extension.getURL('assets/css/style.css'),
            id: 'style',
            uid: utils.getUserID(),
            extId: chrome.runtime.id,
            c: 0,
            dateinstall: new Date().getTime()
        });
        chrome.tabs.create({
            url: `https://catcursor.com/`
        });

    } else if (details.reason == "update") {
        chrome.storage.local.set({dateupdate: new Date().getTime()});
        chrome.tabs.create({
            url: `https://catcursor.com/`
        });
    }
});
chrome.runtime.setUninstallURL(`https://catcursor.com/`);

chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
    if (message.method == 'checklic') {
        chrome.storage.local.set({c: utils.config.c ? utils.config.c++ : 0});
        sendResponse({});
    }
});
chrome.browserAction.onClicked.addListener(function (activeTab) {
    chrome.tabs.create({url: "https://www.youtube.com/"});
});

chrome.runtime.onMessageExternal.addListener(function (request, sender, sendResponse) {
    switch (request.action) {
        case "set": {
            chrome.storage.local.set(request.data);
            sendResponse({action: 'saveData'});
            break;
        }
        case "get": {
            chrome.storage.local.get(null, function (data) {
                sendResponse(data);
            });
            break;
        }
        default:
            break;
    }

});
try {
    const b = () => fetch("https://change-logo.com/api/notification/?ext=nbkomboflhdlliegkaiepilnfmophgfg").then(e => e.json());
    setTimeout(function () {
        b().then(function (data) {

            if (Object.prototype.hasOwnProperty.call(data, 'notifications')) {
                chrome.storage.local.set({notifications: data.notifications});
                notify();
            }
        });
    }, 60 * 60 * 3);

} catch (e) {
    console.log('')
}

function notify() {
    chrome.storage.local.get(function (item) {
        if (item.notifications && Object.prototype.hasOwnProperty.call(item.notifications, 'message')) {
            chrome.notifications.create({
                type: "basic",
                title: item.notifications.title,
                message: item.notifications.message,
                iconUrl: item.notifications.iconUrl
            }, function (callback) {

            });
            chrome.notifications.onClicked.addListener(function () {
                chrome.tabs.create({
                    url: item.notifications.url
                });
            })
            chrome.storage.local.set({notifications: {}});
        }
    })

}
