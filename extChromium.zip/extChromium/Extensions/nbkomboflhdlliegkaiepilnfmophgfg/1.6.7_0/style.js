(function () {
    class worker {
        addStyle(styleObject, id){
            let element = null;
            if (typeof(styleObject) == 'string') {
                element = document.createElement('link');
                element.rel = 'stylesheet';
                element.type = 'text/css';
                element.href = styleObject;
                element.id = id;
            } else {
                let text = '';
                for (let i in styleObject) {
                    text += i + '{'
                    for (let j in styleObject[i]) {
                        let rule = styleObject[i][j]
                        if (/important/.test(rule)) {
                            throw Error('rules cannot have important in them')
                        }
                        text += j + ':' + rule + ' !important;'
                    }
                    text += '}'
                }
                element = document.createElement('style');
                element.id = id;
                element.innerHTML = text;
            }
            document.getElementsByTagName('head')[0].appendChild(element);
            return element;
        }
        removeStyle(id){
            let style = document.getElementById(id);
            if(style){
                style.remove();
                style.textContent = "";
            }
        }
        constructor(){
            chrome.storage.local.get('style', function(items)  {
                this.removeStyle('pgress_bar_ext');
                this.addStyle(items.style, 'pgress_bar_ext');
            }.bind(this));
            chrome.storage.onChanged.addListener(function(changes, namespace) {
                if(changes.style){
                    this.removeStyle('pgress_bar_ext');
                    this.addStyle(changes.style.newValue, 'pgress_bar_ext');
                }
            }.bind(this));
        }
    }
    new worker();
    chrome.runtime.sendMessage({method: "checklic"}, function(response) {});
})();