class Popup{
    constructor(){
        this.styles = [];
        for(let index = 1; index <=30; index++){
            let key = `style_${index}`;
            this.styles[key] = chrome.extension.getURL(`/assets/css/style_${index}.css`);
        }
        this.init();
    }
    init(){
        $("#shareFacebook").attr('href', `https://www.facebook.com/sharer.php?u=https://chrome.google.com/webstore/detail/${chrome.runtime.id}`);
        $("#Rate").attr("href", `https://chrome.google.com/webstore/detail/${chrome.runtime.id}/reviews`);
        $("#star").attr("href", `https://chrome.google.com/webstore/detail/${chrome.runtime.id}`);
        chrome.storage.local.get('id', function(items){
            $(`[data-id=${items.id}]`).addClass('activeT');
        }.bind(this));

        $("li.style").on("click", function (e) {
            let datdaId = $(e.target).data('id');
            chrome.storage.local.set({
                style: this.styles[datdaId],
                id: datdaId
            });
            $('li.activeT').removeClass('activeT');
            $(e.target).addClass('activeT')
        }.bind(this));
    }
}
new Popup();
