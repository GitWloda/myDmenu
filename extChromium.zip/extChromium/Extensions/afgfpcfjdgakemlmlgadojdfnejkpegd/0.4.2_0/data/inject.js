'use strict';

// preferences
const prefs = {
  'playlist': false,
  'visible': false,
  'hidden': false,
  'method': 'stopVideo',
  'policy': 'all', // 'all', 'if-not-playing'
  'pause-on-seek-arg': true
};

const run = cmd => new Promise(resolve => chrome.runtime.sendMessage({
  method: 'run',
  cmd
}, resolve));

const stop = async target => {
  const state = await run('getPlayerState');

  // policy check
  if (prefs.policy === 'if-not-playing' && state === 1) {
    return;
  }
  const href = location.href;
  // https://www.youtube.com/clip/UgkxuqibABalFuZPSceCUlONwubPsXPUw7Yj
  if (href.indexOf('/clip/') !== -1) {
    return;
  }
  if (prefs.playlist || href.indexOf('&list=') === -1 || href.indexOf('&index=') === -1) {
    if (state === -1) {
      document.removeEventListener('canplay', play, true);
    }
    try {
      target.pause();
    }
    catch (e) {}

    // https://www.youtube.com/watch?v=fzF-N0V9DsM&t=1148s
    if (location.search.indexOf('&t=') !== -1 && prefs['pause-on-seek-arg']) {
      run('pauseVideo');
    }
    else {
      run(prefs.method);
    }
  }
};

// visibility
document.addEventListener('visibilitychange', () => {
  if (prefs.visible && document.visibilityState === 'visible') {
    run('playVideo');
    if (prefs.hidden === 'false') {
      prefs.visible = 'false';
    }
  }
  if (prefs.hidden && document.visibilityState === 'hidden') {
    run('pauseVideo');
  }
});

// detect playing
const play = e => {
  stop(e.target);
};
document.addEventListener('canplay', play, true);
document.addEventListener('yt-navigate-finish', () => {
  document.removeEventListener('canplay', play, true);
  document.addEventListener('canplay', play, true);
  stop();
});
document.addEventListener('mousedown', () => document.removeEventListener('canplay', play, true));
document.addEventListener('keydown', () => document.removeEventListener('canplay', play, true));

// prefs
chrome.storage.local.get(prefs, ps => Object.assign(prefs, ps));
chrome.storage.onChanged.addListener(ps => {
  Object.entries(ps).forEach(([key, value]) => prefs[key] = value.newValue);
});
