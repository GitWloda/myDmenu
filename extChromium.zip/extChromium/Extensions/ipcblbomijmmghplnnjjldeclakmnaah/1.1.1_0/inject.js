var popup = false;

$(document).ready(function(){

  chrome.storage.sync.get(["mode", "indent"], function(result){
    if(result.mode == "inline"){
        var items = document.getElementsByClassName("title may-blank loggedin");

        for(var i = 0; i < items.length; i++){
          var a = items[i].href;
          if(result.indent == "max-size"){
              $(items[i]).parent().append('<span class="domain expand" style="cursor: pointer; user-select: none; visibility: visible;" onclick="if(document.getElementById(\'expand-' + i + '\') == null){$(this).parent().parent().parent().parent().append(\'<iframe src=&#34;' + a + '&#34; id=&#34;expand-' + i + '&#34; style=&#34;width: 70%; margin-left: 60px; margin-top: 10px;height: 500px;resize: both;&#34;></iframe>\');}else{document.getElementById(\'expand-' + i + '\').remove();}"> Expand</span>');
          }else if(result.indent == "fit-width"){
            $(items[i]).parent().append('<span class="domain expand" style="cursor: pointer; user-select: none; visibility: visible;" onclick="if(document.getElementById(\'expand-' + i + '\') == null){$(this).parent().parent().parent().append(\'<iframe src=&#34;' + a + '&#34; id=&#34;expand-' + i + '&#34; style=&#34;width: 100%;margin-top: 10px;height: 500px;resize: both;&#34;></iframe>\');}else{document.getElementById(\'expand-' + i + '\').remove();}"> Expand</span>');
          }
        }
    }else if(result.mode == "popup"){
      popup = true;

      $("body").prepend('<div id="ol" style="background-color: rgba(0, 0, 0, 0.5);width: 100%;height: 100%;position: fixed;z-index: 200;display: none;left: 0;top:0;overflow: auto;"><div id="ol-content" style="background: white;margin: 2% auto;width: 90%;border-radius: 7px;padding: 20px;height: 85%;"><span id="ol-close" style="float: right; color: black;font-size: 2em; user-select: none; cursor: pointer;" onclick="$(\'#ol\').hide();document.getElementById(\'ol-frame\').src = \'\';$(\'body\').css(\'overflow\', \'auto\');">&times;</span><br><iframe src="" id="ol-frame" style="width: 100%; height: 90%; border: none;"></iframe></div></div>');

      var it = document.getElementsByClassName("title may-blank loggedin");

      for(var ii = 0; ii < it.length; ii++){
        var aa = it[ii].href;
        $(it[ii]).parent().append('<span class="domain expand" style="cursor: pointer; user-select: none; visibility: visible;" onclick="document.getElementById(\'ol-frame\').src = \'' + aa + '\';$(\'#ol\').show();$(\'body\').css(\'overflow\', \'hidden\');"> Expand</span>');
      }
    }

    $("#ol").click(function(){
      if(popup == true && !$("#ol-content").is(":hover")){
        $("#ol").hide();
        document.getElementById('ol-frame').src = "";
        $("body").css("overflow", "auto");
      }
    });

  });

});

$(document).keyup(function(e) {
     if (e.keyCode == 27 && popup == true) {
        $("#ol").hide();
        document.getElementById('ol-frame').src = "";
        $("body").css("overflow", "auto");
    }
});
