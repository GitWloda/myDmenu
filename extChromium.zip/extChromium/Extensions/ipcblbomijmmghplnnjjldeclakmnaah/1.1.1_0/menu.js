$(document).ready(function(){

  chrome.storage.sync.get(["mode", "indent"], function(result) {
        $("#mode").val(result.mode);
        $("#indent").val(result.indent);
        toggle();
  });

});

$("#mode").change(toggle);

$("#save").click(function(){
  var m = $("#mode").val();
  var i = $("#indent").val();

  chrome.storage.sync.set({mode: m, indent: i}, function(){
    window.close();
  });
});

function toggle(){
  if($("#mode").val() == "inline"){
    $(".in").show();
  }else{
    $(".in").hide();
  }
}
