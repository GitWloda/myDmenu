chrome.runtime.onInstalled.addListener(function(){
  chrome.storage.sync.set({mode: "inline", indent: "fit-width"}, function(){});
});

chrome.tabs.onUpdated.addListener( function (tabId, changeInfo, tab) {
  if (changeInfo.status == 'complete' && tab.url.indexOf("www.reddit.com") != -1) {
    chrome.pageAction.show(tabId);
  }
});
