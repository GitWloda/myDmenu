var donateButton = document.querySelector('#donate');

donateButton.onclick = function() {
  window.open("https://www.paypal.com/donate?hosted_button_id=MD9WRXSTLB49W");
};

document.querySelector('#unlocker').addEventListener('change', function(){
  let customNumber = document.querySelector('#customNumber');
  if (this.checked){
    customNumber.removeAttribute('disabled');
  } else {
    customNumber.setAttribute('disabled', 'true');
  }
  saveSettings();
})

document.querySelector('#customNumber').addEventListener('change', function(){
  saveSettings();
})

function saveSettings(){
  let customNumber = document.querySelector('#customNumber').value;
  let forced = document.querySelector('#unlocker').checked;
  chrome.storage.sync.set({forced: forced, customNumber: customNumber}, function(){
    console.log('Reddit Column View value set to ' + customNumber);
  })
}

function getSettings(){
  chrome.storage.sync.get(['forced'], function(result){
    let forced = document.querySelector('#unlocker');
    let customNumber = document.querySelector('#customNumber');

    if (result.forced == true){
      forced.checked = true;
      customNumber.removeAttribute('disabled');
    }
  })

  chrome.storage.sync.get(['customNumber'], function(result){
    let customNumber = document.querySelector('#customNumber');
    if (Object.keys(result).length != 0) customNumber.value = result.customNumber;
  })
}

getSettings();

