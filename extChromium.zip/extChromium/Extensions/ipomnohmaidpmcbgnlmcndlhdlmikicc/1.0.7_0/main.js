'use strict';
var numberOfColumns;
var screenWidth = window.outerWidth;
var redditURLPath;
var currentObserver;
var checkConditions;
var observerSet = false;
var isRearrangingPosts = false;

function getSmallestColIndex(columnSelector) {
    //get column index with lowest number of items
    let columns = document.querySelectorAll(columnSelector);
    let columnsData = [];
    columns.forEach(element => {
        columnsData.push(element.childElementCount);
    });
    let minValue = Math.min.apply(null, columnsData);
    return columnsData.indexOf(minValue);
}

function getShortestColIndex(columnSelector) {
    //get column index with lowest height
    let columns = document.querySelectorAll(columnSelector);
    let columnsData = [];
    columns.forEach(element => {
        columnsData.push(element.offsetHeight);
    });
    let minValue = Math.min.apply(null, columnsData);
    return columnsData.indexOf(minValue);
}

function startOldReddit() {
    var posts = document.querySelectorAll('#siteTable > div.thing');
    if (posts.length <= 1) return;

    //add custom styles
    var columnStyle = document.createElement('style');
    columnStyle.id = 'column-style';
    var styleContent = `
.linklisting .link {
margin-right: 0 !important;
}

@media (max-width: 1500px){
.column-div {
flex: 100% !important;
}
}
`;
    columnStyle.appendChild(document.createTextNode(styleContent));
    document.body.append(columnStyle);

    //set container to flex
    document.querySelector('#siteTable').style.display = 'flex';
    document.querySelector('#siteTable').style.alignItems = 'flex-start';
    document.querySelector('#siteTable').style.flexWrap = 'wrap';

    //add column containers
    var flexValue = 100 / numberOfColumns;
    for (var i = 0; i < numberOfColumns; i++) {
        var columnDiv = document.createElement('div');
        columnDiv.id = 'column-div-' + i;
        columnDiv.style = `flex: 0 0 ${flexValue}%;`;
        columnDiv.classList.add('column-div');
        document.querySelector('#siteTable').append(columnDiv);
    }
    rearrangePosts();
    setObserver();

    function rearrangePosts() {
        //rearrange into columns
        for (var i = 0, colIndex = 0; i < posts.length; i++) {
            var currentColumn = document.querySelector('#column-div-' + colIndex);
            currentColumn.append(posts[i]);
            colIndex++;
            if (colIndex >= numberOfColumns) {
                colIndex = 0; //reset to first column if end reached
            }
        }

        //remove clears
        var clears = document.querySelectorAll('#siteTable > div.clearleft');
        clears.forEach(element => {
            element.remove();
        });

        //reposition nav buttons
        var navButtons = document.querySelector('#siteTable > div.nav-buttons');
        var siteTable = document.querySelector('#siteTable');
        var main = document.querySelector('div.content[role="main"]');
        main.insertBefore(navButtons, siteTable.nextSibling);
    }

    function rearrangePostsRES() {
        var RESPageAll = document.querySelectorAll('div.NERPageMarker');
        var RESPage = RESPageAll[RESPageAll.length - 1];
        if (RESPage != null) {
            posts = RESPage.nextSibling.querySelectorAll('div.thing:not(.promoted)');
            //rearrange into columns
            for (var i = 0; i < posts.length; i++) {
                var colIndex = getShortestColIndex('.column-div');
                var currentColumn = document.querySelector('#column-div-' + colIndex);
                currentColumn.append(posts[i]);
                colIndex++;
                if (colIndex >= numberOfColumns) {
                    colIndex = 0; //reset to first column if end reached
                }
            }
            RESPage.nextSibling.style.opacity = '0';
            RESPage.style.opacity = '0';
        };
    }

    function setObserver() {
        var posts = document.querySelector('#siteTable');
        var observerConfig = {
            childList: true
        }
        var observer = new MutationObserver(rearrangePostsRES);
        observer.observe(posts, observerConfig);
    }
}

  function startNewReddit() {
      var postsContainer = document.querySelector('#SHORTCUT_FOCUSABLE_DIV > div > div > div > div > div:nth-child(2) > div:last-child > div');
      var postsInner = document.querySelector('#SHORTCUT_FOCUSABLE_DIV > div > div > div > div > div:nth-child(2) > div:last-child > div > div:nth-last-child(2)');
      if (postsInner != null && postsInner.childElementCount <= 1) {
        postsInner = document.querySelector('#SHORTCUT_FOCUSABLE_DIV > div > div > div > div > div:nth-child(2) > div:last-child > div > div:last-child');
      }
      var currentLayout = !!document.querySelector('#LayoutSwitch--picker > span:nth-child(2)') ? document.querySelector('#LayoutSwitch--picker > span:nth-child(2)').textContent : '';
      if ((postsInner != null && postsInner.childElementCount <= 1) || postsInner == null || currentLayout == "classic" || currentLayout == "compact" || location.href.includes('/comments/') || location.pathname.includes('/submit') || location.pathname.includes('/duplicates/')) {
          checkConditions = setTimeout(() => { //repeat to see if user back on main page
              startNewReddit();
          }, 500)
          return
      };
      if (!document.querySelector('#colCont')) {
        //add custom styles
        var columnStyle = document.createElement('style');
        columnStyle.id = 'column-style';
        var styleContent = `
    .column-div-new:not(:last-child) {
    margin-right:10px;
    }
    @media (max-width: 1200px){
    .column-div-new {
    flex: 100% !important;
    }
    }
    .column-div-new {
    min-width: 0;
    }
    `;
        columnStyle.appendChild(document.createTextNode(styleContent));
        document.body.append(columnStyle);

        //add column containers
        var columnsContainer = document.createElement('div');
        columnsContainer.id = 'colCont';
        columnsContainer.classList.add('column-wrapper');
        columnsContainer.style = 'display: flex; flex-wrap: wrap; align-items: flex-start;';
        postsInner.prepend(columnsContainer);

        addColumnDivs();
      };

      checkIfColumsAdded();

      function checkIfColumsAdded() {
          var checkIfDone = setInterval(() => { //check if containers were properly added
              var currentCols = document.querySelectorAll('.column-div-new').length;
              if (currentCols >= numberOfColumns) {
                  clearInterval(checkIfDone);
                  postsContainer.style.width = '100%';
                  //set observer for infinite scrolling    
                  if (!observerSet) {
                      setObserver();
                      observerSet = true;
                  }
                  rearrangePostsNew();
              } else {
                  addColumnDivs(currentCols);
              }
          }, 100)
          setTimeout(() => { //stop after X seconds
              clearInterval(checkIfDone);
          }, 15000);
      }

      function addColumnDivs(offset) {
          var colOffset = offset == undefined ? 0 : offset;
          var flexValue = (100 - numberOfColumns) / numberOfColumns;
          for (var i = 0 + colOffset; i < numberOfColumns; i++) {
              var columnDiv = document.createElement('div');
              columnDiv.id = 'column-div-' + i;
              columnDiv.style = `flex: ${flexValue}%;`;
              columnDiv.classList.add('column-div-new');
              columnsContainer.append(columnDiv);
          }
      }

      function rearrangePostsNew() {
          if (isRearrangingPosts) return;
          //rearrange into columns
          isRearrangingPosts = true;
          var posts = postsInner.children;
          for (var i = 0; i < posts.length; i++) {
              let colIndex = getShortestColIndex('.column-div-new');
              if (posts[i].classList.contains('column-wrapper') || (posts[i].firstChild != null && posts[i].firstChild.innerHTML == "")) continue;
              if (posts[i].offsetHeight == 0) continue //posts[i].style.display = 'none';
              posts[i].style.marginBottom = '10px';
              var currentColumn = document.querySelector('#column-div-' + colIndex);
              currentColumn.append(posts[i]);
              colIndex++;
              if (colIndex >= numberOfColumns) {
                  colIndex = 0; //reset to first column if end reached
              }
          }
          isRearrangingPosts = false;
      }

      function setObserver() {
          var observerConfig = {
              childList: true
          }
          currentObserver = new MutationObserver(rearrangePostsNew);
          currentObserver.observe(postsInner, observerConfig);
      }
  }

//get settings and start
function start() {
    chrome.storage.sync.get(['forced'], function (result) {
        if (result.forced == true) {
            chrome.storage.sync.get(['customNumber'], function (result) {
                numberOfColumns = result.customNumber == '' ? numberOfColumns : result.customNumber;
                chooseLayout(true);
            })
        } else {
            chooseLayout(false);
        }
    })
}

function chooseLayout(isForced) {
    //choose layout
    if (!!document.querySelector('#siteTable')) {
        if (!isForced) {
            if (screenWidth >= 3000) {
                numberOfColumns = 4;
            } else if (screenWidth >= 2200) {
                numberOfColumns = 3;
            } else {
                numberOfColumns = 2;
            }
        }
        startOldReddit();
    }; //for old layout
    if (!!document.querySelector('#SHORTCUT_FOCUSABLE_DIV')) {
        if (!isForced) { //one more column for new reddit;
            if (screenWidth >= 3000) {
                numberOfColumns = 5;
            } else if (screenWidth >= 2200) {
                numberOfColumns = 4;
            } else {
                numberOfColumns = 3;
            }
        }
        startNewReddit();
    }; //for redesign
}
  
function checkForUrlChanges() {
    redditURLPath = location.href;
    var checkURLChange = setInterval(function () {
        if (location.href != redditURLPath) {
            redditURLPath = location.href;
            if (currentObserver != undefined) currentObserver.disconnect();
            observerSet = false;
            clearTimeout(checkConditions);
            start();
        }
    }, 500);
}

checkForUrlChanges();
start();